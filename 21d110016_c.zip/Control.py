import numpy as np
from scipy.integrate import odeint

g = 9.8
r = 0.1
phi = 0

# The following function gives the ordinary differential
# equation that our plant follows. Do not meddle with this.
def f(x, t, theta):
    return (x[1], (-5 * g / 7) * np.radians(theta))


class pid_controller:
    def __init__(self, Kp, Ki, Kd, setpoint, dt, integral_limit=100):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.setpoint = setpoint
        self.dt = dt
        self.integral_limit = integral_limit

        self.prev_error = 0
        self.integral = 0

    def update(self, feedback):
        error = self.setpoint - feedback

        # PID control equations
        self.integral += error * self.dt
        self.integral = np.clip(self.integral, -self.integral_limit, self.integral_limit)

        derivative = (error - self.prev_error) / self.dt

        output = self.Kp * error + self.Kd * derivative + self.Ki * self.integral

        self.prev_error = error

        return output


def solve(pid_controller, x_value, theta):
    global x, phi

    # PID control
    control_signal = pid_controller.update(x_value)

    # Apply saturation limits
    control_signal = np.clip(control_signal, -15, 15)

    # Integrate the system state using odeint
    t = np.arange(0, pid_controller.dt, 0.01)
    x_theta = odeint(f, (x_value, control_signal), t, args=(theta,))
    x_value, dx = x_theta[-1]
    x_value += dx
    return dx, x_value

